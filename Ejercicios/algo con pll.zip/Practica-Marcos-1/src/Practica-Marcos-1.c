/*
===============================================================================
 Name        : Practica-Marcos-1.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#include <stdint.h>
#include <cr_section_macros.h>

#define AddrFIO0DIR 0x2009C000
#define AddrFIO0SET 0x2009C018
#define AddrFIO0CLR 0x2009C01C
#define AddrFIO0PIN 0x2009C014

unsigned int volatile * const FIO0DIR = (unsigned int *) AddrFIO0DIR;
unsigned int volatile * const FIO0SET = (unsigned int *) AddrFIO0SET;
unsigned int volatile * const FIO0CLR = (unsigned int *) AddrFIO0CLR;
unsigned int volatile * const FIO0PIN = (unsigned int *) AddrFIO0PIN;
unsigned int volatile * const CLKSRCSEL = (unsigned int *) 0x400FC10C;					// selecciona la fuente de reloj
unsigned int volatile * const PLL0CON = (unsigned int *) 0x400FC080;						// habilita y activa el pll
unsigned int volatile * const PLL0CFG = (unsigned int *) 0x400FC084;						// configurador del pll (multipicador M y divisor N)
unsigned int volatile * const PLL0STAT = (unsigned int *) 0x400FC088;					// estado de las cofiguraciones del pll
unsigned int volatile * const PLL0FEED = (unsigned int *) 0x400FC08C;					// registro para cargar dos secuencias de numeros para aceptar cambios en la conf del pll
unsigned int volatile * const CCLKCFG = (unsigned int *) 0x400FC104;
unsigned int volatile * const SCS = (unsigned int *) 0x400FC1A0;						// registro para habilitar el oscilador principal y ver el estado
unsigned int volatile * const PINMODE0 = (unsigned int *) 0x4002C040;

void confClock();

int main(void)
{
	confClock();

	*FIO0DIR |= 0xF0;
	*PINMODE0 = 0xAA;

	int aux = *FIO0PIN & 0xF;
	*FIO0SET = (aux << 4);

	while(1)
	{
		if((*FIO0PIN & 0xF) != aux)
		{
			aux = *FIO0PIN & 0xF;
			*FIO0CLR = 0xF0;
			*FIO0SET = (aux << 4);
		}

	}

    return 0 ;
}


void confClock()
{
	*PLL0CON = 0;//&= ~(1 << 1);						// desconecto y deshabilito pll
	*PLL0FEED = 0xAA; 									// secuencia de alimentacion
	*PLL0FEED = 0x55;

	*SCS = 0x20;										// enciendo el cristal
	while((*SCS & (1 << 6)) == 0);						// espero a que se estabilice
	*CLKSRCSEL |= 1;  									// ahora selecciono al oscilador principal (cristal de 12 mHz) como fuente de clock
	*CCLKCFG = 2; 										// divisor en la salida del pll = 3



	*PLL0CFG = ((1 << 16) + (24&0x7FFF));	  			// M = 25 y N = 2
	*PLL0FEED = 0xAA; 									// secuencia de alimentacion
	*PLL0FEED = 0x55;

	*PLL0CON = 1;										// habilito pll
	*PLL0FEED = 0xAA; 									// secuencia de alimentacion
	*PLL0FEED = 0x55;

	while(!(*PLL0STAT & (1 << 26))); 					// espero a que el pll enganche a la frecuencia deseada

	*PLL0CON = 3; // se conecta el pll
	*PLL0FEED = 0xAA; // secuencia de alimentacion
	*PLL0FEED = 0x55;

}
