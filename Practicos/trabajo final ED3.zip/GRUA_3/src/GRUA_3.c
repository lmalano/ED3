/*
===============================================================================
 Name        : GRUA_3.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cr_section_macros.h>

// Declaracion de las funciones de configuracion
void TIMER_config(void);
void UART_config(void);
void ADC_config (void);
void EXTERNA0_config(void);
void SYS_config (void);
void GPIO_config (void);

// Declaracion de las funciones de operacion
void Enviar (char);
void GIRAR (int);

// Declaracion de los punteros para SysTick

unsigned int volatile * const STCTRL = (unsigned int *)0xE000E010;
unsigned int volatile * const STRELOAD = (unsigned int *)0xE000E014;
unsigned int volatile * const STCURR = (unsigned int *)0xE000E018;

// Declaracion de variables
int contador = 250; // arrancaria al medio del recorrido
int Valor_Conv_Act =0; // valor actual del ADC
int Valor_Conv_Anterior =0; // valor anterior del ADC
int Fin_Carrera_Max = 1000; // 50 giros para llegar al extremo superior de la torre
int Fin_Carrera_Min = 0;  // valor umbral que representa la menor altura, es decir la mayor extension de la cuerda
unsigned int resultadoADC;


int main(void) {

    //Llamamos a las funciones de configuracion de los perifericos
	GPIO_config();
	TIMER_config();
	UART_config();
	EXTERNA0_config();
	ADC_config();
	SYS_config();

	// INICIO EL TIMER COUNTER DEL TIMER 0
		LPC_TIM0->TCR =(1<<0);



    // Loop de espera
    while(1) {
        // LEER EL VALOR DEL NIVEL P2.10,DE P2.11 Y P2.12
    }
    return 0 ;
}



void GPIO_config(void)
{
	// Para el encoder
	LPC_GPIO0->FIODIR|=(1<<9); // P0.9 como salida para energizar el encoder
	LPC_GPIO0->FIOSET|=(1<<9); //  ENERGIZAR EL ENCODER
	LPC_GPIO0->FIODIR|=(0<<18); // P0.18 como entrada del canal B del encoder
	// Para los led
	LPC_GPIO3->FIODIR|=(1<<25); // P3.25 salida para LED VERDE
	LPC_GPIO3->FIODIR|=(1<<26); // P3.26 salida para LED AZUL
	// Para el puente H
	LPC_GPIO0->FIODIR|=(1<<6); // P0.6 como salida para habilitar el motor A en el puente H
	LPC_GPIO0->FIOSET|=(1<<6);  // habilitamos el motor A
	LPC_GPIO0->FIODIR|=(1<<7); //P0.7 CONTROL1 PTE H motor A
	LPC_GPIO0->FIODIR|=(1<<8); //P0.8 CONTROL2 PTE H motor A (EL MOTOR SE PRENDE EN MATCH1)
}

void TIMER_config(void)
{
	LPC_SC->PCONP |=(1<<1); //Enciendo el timer0
	LPC_TIM0->TC=0; //REINICIO EL PC
	LPC_TIM0->TCR=2;
	//Configuracion del Timer0
	LPC_TIM0->PR = 0; //Al poner el Preescaler igual a 0, el timer counter se incrementara con cada pulso de clock
	LPC_TIM0->MR0 = 10000; // Cargo un valor al MR0
	LPC_TIM0->MR1 = 250000; // Cargo un valor al MR1

	//Configuracion del MCR
	LPC_TIM0->MCR|=(1<<0); // Se genera una interrupcion cuando el MR0 se matchea con el TC (timer counter)
	LPC_TIM0->MCR|=(1<<3); // Se genera una interrupcion cuando el MR1 se matchea con el TC (timer counter)
	LPC_TIM0->MCR|=(1<<4); // Se reinicia el TC cuando el MR1 se matchea con el.
	// habilito interrupcion por timer 0
		NVIC_EnableIRQ(TIMER0_IRQn);


}

void UART_config(void)
{
	LPC_SC->PCONP |= (1 << 25); //ENCENDEMOS EL PERIFERICO UART3
	LPC_UART3->LCR |= (1 << 0); // PARA UNA LONGITUD DEL MENSAJE DE 8 BITS
	LPC_UART3->LCR |= (1 << 1); // CONFIGURO LOS BITS 0 Y 1
	LPC_UART3->LCR |= (1 << 7); //PARA ACCEDER A DLL Y DLM

	//CONFIGURACION DE TASA DE TRANSMISION A 9600
	LPC_UART3->DLL = 162;
	LPC_UART3->DLM = 0;
	LPC_UART3->LCR &= ~(1 << 7); //YA CONFIGURADO, DESHABILITO EL ACCESO
	LPC_UART3->IER |= (1 << 0); //HABILITO INTERR. DE RECEPCION
	//NVIC_EnableIRQ(UART3_IRQn); // Habilito las interrupciones globales para UART3
	LPC_PINCON->PINSEL0 |= (1 << 1); //HABILITO TX3
	LPC_PINCON->PINSEL0 |= (1 << 3); //HABILITO RX3
}

void ADC_config (void)
{

	LPC_SC->PCONP |=(1<<12); //ENERGIZO EL PERIFERICO(ADC).bit12 PCADC
	LPC_ADC->ADCR |= (1<<21); // ENCIENDO EL CONVERSOR.
	LPC_ADC->ADCR |= (1<<0); // ELIGO EL CANAL 0 DEL CONVERSOR.NO SERIA NECESARIO
	LPC_SC->PCLKSEL0 &= ~(1 << 24); // selecciono clock de adc en sysclock / 4
	LPC_ADC->ADCR |= (1<<8); // divido PCLk por 2, 25 / 2 y de 12,5 que es < 13Mhz
	LPC_ADC->ADCR |= (1<<16); // activo modo Burst-conversion continua
	LPC_ADC->ADINTEN &= ~(1<<8); // bit ADGINTEN debe ser 0 en modo burst.
	LPC_ADC->ADCR &= ~ (1<<24); // bit start debe ser 000, en modo BURST, para iniciar la conversion

}

void SYS_config (void)
{

	*STRELOAD=0xF423F; //valor cargado en el contador Para 10ms
	*STCURR =0;
	*STCTRL|=7; //bit0 ENABLE=1, TICKINT=1 interrupcion por sistick habilitada, CLKSOURCE=1 el clock del cpu es seleccionado
}

void EXTERNA0_config(void)
{
	LPC_PINCON->PINSEL4|= (1<<20); // CONFIGURAMOS P2.10 PARA USAR EXTERNA0
	LPC_PINCON->PINSEL4|= (1<<22); // CONFIGURAMOS P2.11 PARA USAR EINT1
	LPC_GPIO2->FIODIR|= (0<<10); //PIN 2.10 ENTRADA
	LPC_GPIO0->FIODIR|= (0<<18); //PIN 0.18 ENTRADA
	//LPC_SC->EXTINT|=(1<<0); // HABILITAMOS EXTERNA0
	LPC_SC->EXTMODE|=(1<<0); //INTERRUPCION EXTERNA EXTERNA0 POR FLANCO
	LPC_SC->EXTMODE|=(0<<1); //INTERRUPCION EXTERNA EINT1 POR NIVEL
	LPC_SC->EXTPOLAR|=(1<<0); // INTERRUPCION EXTERNA EXTERNA0 POR FLANCO ASCENDENTE
	LPC_SC->EXTPOLAR|=(1<<1); // INTERRUPCION EXTERNA EINT1 POR FLANCO ASCENDENTE
	NVIC_EnableIRQ(EINT0_IRQn); // Habilitamos interrupcion general por EXTERNA0
	NVIC_EnableIRQ(EINT1_IRQn); // Habilitamos interrupcion general por EINT1
}

// FIN DE LAS FUNCIONES DE CONFIGURACION

// INICIO DE LOS HANDLERS

void TIMER0_IRQHandler (void)
{
	if (LPC_TIM0->IR &(1<<0))
	{   LPC_GPIO0->FIOCLR|=(1<<6);
		//Deshabilito el puente H: APAGO EL MOTOR
		 // Disminuyo el valor de MR0 para ajustar suavemente el PWM en el arranque
		LPC_TIM0->IR=1;

	}
	else if (LPC_TIM0->IR &(1<<1))
	{   LPC_GPIO0->FIOSET|=(1<<6); // habilito el puente H: PRENDO EL MOTOR
		LPC_TIM0->IR|=(1<<1);
		if (LPC_TIM0->MR0 < 22000)
			{LPC_TIM0->MR0= LPC_TIM0->MR0 + 10000;}
	}

}


void  SysTick_Handler(void){
	//aqui va la interrupcion

	resultadoADC=((LPC_ADC->ADDR0& (0xfff<<4))>>4); //L

	//resultadoADC = LPC_ADC->ADDR0; // 1) se guarda el valor de ad0gdr en resultadoADC (tabla 533) L
	//resultadoADC >>= 8;		       // 2) se desplaza 8 lugares a derecha para justificar los bits del resultado a derecha
	//resultadoADC &= 0x000000ff;   // 3) se enmascara para guardar exclusivamente los 8 bits del resultado


	//j=(*AD0DR0>>8)&0xff;//se guarda el valor real de la convercion de ADODRO-RESULT en j
	     	 	 	 	 	// se en enmascara para guardar los 8 bits del resultado mas significativo
	//LPC_ADC->ADINTEN |= (1<<0); // Seteo la bandera de la interrupcion del ADC.

	if(resultadoADC < 2000)  //agregado x L
		{
			LPC_GPIO0->FIOCLR |= (1 << 8);
			LPC_GPIO0->FIOSET |= (1 << 7);// Gira a la "derecha"
		}

//	else if (resultadoADC>1700 && resultadoADC<3500)
	//{LPC_GPIO0->FIOCLR|=(1<<6);} //apaga motor en puntomedio

		else 			//else if (resultadoADC>3500 && resultadoADC<4095) loreley m dijo asi
			{
				LPC_GPIO0->FIOCLR |= (1 << 7);
				LPC_GPIO0->FIOSET |= (1 << 8);// Gira a la "izquierda"

				}
//	GIRAR(resultadoADC); // LLamo a la funcion girar.
}

void EINT0_IRQHandler (void){

	//char buffer[20]; // para almacenar el valor convertido
	if (LPC_GPIO2->FIOPIN&(1<<11))
		{LPC_GPIO3->FIOSET|=(1<<26);
			if (contador < 500)
				{contador++; // si el giro es hacia la derecha aumenta el contador
							}

				else {LPC_GPIO0->FIOCLR|=(1<<6);
				// APAGA EL MOTOR
				}
		LPC_GPIO3->FIOCLR|=(1<<25); //prendo el led verde indicando el sentido del giro
		}

	else
	{LPC_GPIO3->FIOSET|=(1<<25);
		if (contador > 0)
		{contador--; // si el giro es hacia la izquierda disminuye el contador
			}
		else {LPC_GPIO0->FIOCLR|=(1<<6); // APAGA EL MOTOR
	}
		LPC_GPIO3->FIOCLR|=(1<<26); // prendo el led azul indicando el sentido de giro a la izquierda
	}
	//itoa (contador, buffer,10);
	//char buffer[20];
	//itoa(contador,buffer,2);   // here 2 means binary
	Enviar (contador);
	LPC_SC->EXTINT|=(1<<0); //BAJO BANDERA

}



// DEFINICION DE FUNCIONES GENERALES

void Enviar (char k){
	LPC_UART3->THR=k;
}

void GIRAR(int p)
{


	if(p < 2048)
	{
		LPC_GPIO0->FIOCLR |= (1 << 8);
		LPC_GPIO0->FIOSET |= (1 << 7);// Gira a la "derecha"


	}

	else
		{
			LPC_GPIO0->FIOCLR |= (1 << 7);
			LPC_GPIO0->FIOSET |= (1 << 8);// Gira a la "izquierda"

			}

}


void EINT1_IRQHandler(void)
		{
	LPC_SC->EXTINT|=(1<<1); //BAJO BANDERA
		}
