/*
===============================================================================
 Name        : GRUA2.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>

// Declaracion de las funciones
void TIMER_conf(void);
void UART_config(void);
void ADC_config (void);
void EINT0_conf(void);


// Registro para declarar prioridades
unsigned int volatile *const STCTRL = (unsigned int*) 0xE000E010; //Registro de control del systick
unsigned int volatile *const STRELOAD = (unsigned int*)0xE000E014; //Registro de carga del systick
int contador =0; // contador que aumentara si el giro es en sentido horario (dextrogiro)
					 // y descendera si el giro es en sentido antihorario (levogiro)

int valor_anterior =0; // valor anterior medido por el adc


int main(void) {

	//*IPR5|=(1>>23); // configuramos una baja prioridad para el ADC

	// Llamo a las funciones de configuracion;
	TIMER_conf();
	UART_config();
	ADC_config ();
	EINT0_conf();


	LPC_GPIO0->FIOSET|=(1<<9); //PONGO UN 1 EN P0.9 PARA ENERGIZAR EL ENCODER
	LPC_GPIO3->FIODIR|=(1<<25); // P3.25 LED VERDE
	LPC_GPIO3->FIODIR|=(1<<26); // P3.26 LED AZUL
	LPC_GPIO0->FIODIR|=(1<<6);

	LPC_GPIO0->FIOSET|=(1<<6);  // habilitamos el motor A

	LPC_GPIO0->FIODIR|=(1<<7); //P0.7 CONTROL1 PTE H
	LPC_GPIO0->FIODIR|=(1<<8); //P0.8 CONTROL2 PTE H

/*
	*STCTRL|=(1<<2);
	*STRELOAD=(999999);
	*STCTRL|=(1<<0);
	*STCTRL|=(1<<1);
	//SysTick_Config(SystemCoreClock / 10000); // inicio e inicio el contador del systick timer
*/
    while(1) {

    }
    return 0 ;
}

//Inicio de las configuraciones


void TIMER_conf(void)
{
	LPC_SC->PCONP |=(1<<1); //Enciendo el timer0
	//Configuracion del Timer0
	LPC_TIM0->PR = 0; //Al poner el Preescaler igual a 0, el timer counter se incrementara con cada pulso de clock
	LPC_TIM0->MR0 = 300000; // Cargo un valor al MR0
	LPC_TIM0->MR1 = 5000000; // Cargo un valor al MR1
	LPC_TIM0->MR2 = 2000000; // para controlar el adc
	  	//Configuracion del MCR

	LPC_TIM0->MCR|=(1<<0); // Se genera una interrupcion cuando el MR0 se matchea con el TC (timer counter)
	LPC_TIM0->MCR|=(1<<3); // Se genera una interrupcion cuando el MR1 se matchea con el TC (timer counter)
	LPC_TIM0->MCR|=(1<<4); // Se reinicia el TC cuando el MR1 se matchea con el.
	LPC_TIM0->MCR|=(1<<6); // Interrupcion por MR2

	// INICIO EL TIMER COUNTER DEL TIMER 0
	LPC_TIM0->TCR|=(1<<0);
	NVIC_EnableIRQ(TIMER0_IRQn); // habilito interrupcion por timer 0

}

void EINT0_conf(void)
{
		LPC_PINCON->PINSEL4|= (1<<20); // CONFIGURAMOS P2.10 PARA USAR EINT0
		LPC_GPIO2->FIODIR|= (0<<10); //PIN 2.10 ENTRADA
		LPC_GPIO2->FIODIR|= (0<<11); //PIN 2.11 ENTRADA
		LPC_SC->EXTINT|=(1<<0); // HABILITAMOS EINT0
		LPC_SC->EXTMODE|=(1<<0); //INTERRUPCION EXTERNA EINT0 POR FLANCO
		LPC_SC->EXTPOLAR|=(1<<0); // INTERRUPCION EXTERNA EINT0 POR FLANCO ASCENDENTE
		NVIC_EnableIRQ(EINT0_IRQn); // Activamos interrupcion general por EINT0
}

void UART_config (void)
{
		LPC_SC->PCONP |= (1 << 25); //ENCENDEMOS EL PERIFERICO UART3
		LPC_UART3->LCR |= (1 << 0); // PARA UNA LONGITUD DEL MENSAJE DE 8 BITS
		LPC_UART3->LCR |= (1 << 1); // CONFIGURO LOS BITS 0 Y 1
		LPC_UART3->LCR |= (1 << 7); //PARA ACCEDER A DLL Y DLM
	    //CONFIGURACION DE TASA DE TRANSMISION A 9600
		LPC_UART3->DLL = 162;
		LPC_UART3->DLM = 0;
		LPC_UART3->LCR &= ~(1 << 7); //YA CONFIGURADO, DESHABILITO EL ACCESO
		LPC_UART3->IER |= (1 << 0); //HABILITO INTERR. DE RECEPCION
		NVIC_EnableIRQ(UART3_IRQn); // Habilito las interrupciones globales para UART3
		LPC_PINCON->PINSEL0 |= (1 << 1); //HABILITO TX3
		LPC_PINCON->PINSEL0 |= (1 << 3); //HABILITO RX3

}

void ADC_config (void)
{
	LPC_SC->PCONP|=(1<<12); //Habilito energia para el ADC
	LPC_PINCON->PINSEL1|=(1<<14); // P0.23 como CH0 del ADC
	LPC_PINCON->PINMODE1|=(1<<15); // Las resistencias pull-up y pull-down del pin P0.23 estan desactivadas
	/*LPC_ADC->ADCR|=(1<<0); // Conversion por canal 0
	LPC_ADC->ADCR|=(1<<9); // Divisor del pclock por 2, para que quede 12,5 MHz
	LPC_ADC->ADCR|=(1<<16); // ADC en modo BURST
*/
	LPC_ADC->ADCR=0x00210101;
	//LPC_ADC->ADINTEN|=(1<<0); // Configuramos interrupciones para el canal 0
	//NVIC_EnableIRQ(ADC_IRQn); // Habilitamos interrupcion global de NVIC
}

//Fin de las configuraciones

// Inicio de los Handlers

void EINT0_IRQHandler (void){

	//char buffer[20]; // para almacenar el valor convertido
	if (LPC_GPIO2->FIOPIN&(1<<11))
	{ 	LPC_GPIO3->FIOSET|=(1<<26);
		contador++; // si el giro es hacia la derecha aumenta el contador
		LPC_GPIO3->FIOCLR|=(1<<25);
	}
	else
	{LPC_GPIO3->FIOSET|=(1<<25);
		contador--; // si el giro es hacia la izquierda disminuye el contador
		LPC_GPIO3->FIOCLR|=(1<<26);
	}
	//itoa (contador, buffer,10);
	Enviar (contador);
	LPC_SC->EXTINT|=(1<<0); //BAJO BANDERA

}

void Enviar (char k){
	LPC_UART0->THR=k;
}

void TIMER0_IRQHandler (void)
{
	if (LPC_TIM0->IR &(1<<0))
	{   LPC_GPIO0->FIOSET|=(1<<7);
		//*FIO0CLR=(1<<7);
	if (!(LPC_TIM0->MR0 < 10000))
		LPC_TIM0->MR0= LPC_TIM0->MR0 - 2000;

      LPC_TIM0->IR=1;
			}
	else if (LPC_TIM0->IR &(1<<1))
	{   LPC_GPIO0->FIOCLR|=(1<<7); // Apago el LED VERDE del RGB
		//*FIO0CLR|=(1<<8); //Prendo el LED AZUL del RGB
	LPC_TIM0->IR|=(1<<1);
	}
	if (LPC_TIM0->IR>>2&1)
	{
		int aux =((LPC_ADC->ADDR0& (0xfff<<4))>>4);
					if (aux <2048)
				{
					LPC_GPIO0->FIOSET|=(1<<7);
					LPC_GPIO0->FIOCLR|=(1<<6); // Giro hacia la izquierda
				}
				else
				{
					LPC_GPIO0->FIOSET|=(1<<6);
					LPC_GPIO0->FIOCLR|=(1<<7); // Giro hacia la derecha
				}
	} //FIN DEL TERCER IF INTERNO
} //FIN DE LA FUNCION
/*
void SysTick_Handler (void)
{
	int aux =((LPC_ADC->ADDR0& (0xfff<<4))>>4);
			if (aux <2048)
		{
			LPC_GPIO0->FIOSET|=(1<<7);
			LPC_GPIO0->FIOCLR|=(1<<6); // Giro hacia la izquierda
		}
		else
		{
			LPC_GPIO0->FIOSET|=(1<<6);
			LPC_GPIO0->FIOCLR|=(1<<7); // Giro hacia la derecha
		}
}
/*

/*
void ADC_IRQHandler(void)
{
	int aux =((LPC_ADC->ADDR0& (0xfff<<4))>>4);
		if (aux <2048)
	{
		LPC_GPIO0->FIOSET|=(1<<7);
		LPC_GPIO0->FIOCLR|=(1<<8); // Giro hacia la izquierda
	}
	else
	{
		LPC_GPIO0->FIOSET|=(1<<8);
		LPC_GPIO0->FIOCLR|=(1<<7); // Giro hacia la derecha
	}

}*/



