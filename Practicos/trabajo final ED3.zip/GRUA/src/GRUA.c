/*
===============================================================================
 Name        : GRUA.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#include <stdlib.h>

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>

//Declaramos Punteros PUERTO 0
unsigned int volatile *const FIO0DIR = (unsigned int*)0x2009C000;
unsigned int volatile *const FIO0SET = (unsigned int*)0x2009C018;
unsigned int volatile *const FIO0CLR = (unsigned int*)0x2009c01c;
unsigned int volatile *const FIO0PIN = (unsigned int*)0x2009c014;
unsigned int volatile *const PINMODE1 = (unsigned int*)0x4002C044;
unsigned int volatile *const IO0INTENR = (unsigned int*)0x40028090;

// Declaramos Punteros PUERTO 2
unsigned int volatile *const FIO2DIR = (unsigned int*)0x2009C040;
unsigned int volatile *const FIO2SET = (unsigned int*)0x2009C058;
unsigned int volatile *const FIO2PIN = (unsigned int*)0x2009c054;

//Declaramos Punteros PUERTO 3
unsigned int volatile *const FIO3DIR = (unsigned int*)0x2009C060;
unsigned int volatile *const FIO3CLR = (unsigned int*)0x2009c07c;
unsigned int volatile *const FIO3SET = (unsigned int*)0x2009C078;

unsigned int volatile *const ISER0 = (unsigned int*)0xE000E100;
unsigned int volatile *const PINSEL4 = (unsigned int*) 0x4002C010;


void Enviar (char k);


//unsigned int volatile *const PCOP = (unsigned int) 0X400FC0C4;
unsigned int volatile *const LCR = (unsigned int) 0X4009C00C;
unsigned int volatile *const DLL = (unsigned int) 0X4009C000;
unsigned int volatile *const DLM = (unsigned int) 0X4009C004;
unsigned int volatile *const PINSEL0 = (unsigned int) 0X4002C000;
unsigned int volatile *const THR = (unsigned int) 0X4009C000;
unsigned int volatile *const RBR = (unsigned int) 0X4009C000;
unsigned int volatile *const IER = (unsigned int) 0X4009C004;
unsigned int volatile *const ISER = (unsigned int) 0XE000E100;

//Declaramos punteros para manejar el Timer0
unsigned int volatile *const T0IR = (unsigned int*)0x40004000; // bit de interrupcion (flag)
unsigned int volatile *const T0TCR = (unsigned int*)0x40004004; //registro del TCR, sirve para controlar las funciones del timer counter
unsigned int volatile *const T0PR = (unsigned int*)0x4000400C; //Preescaler register, cuando el preescaler counter alcanza el valor almacenado aca, se incrementa el TC (TimerCounter)
unsigned int volatile *const T0MCR = (unsigned int*)0x40004014; //Match control register
unsigned int volatile *const T0MR0 = (unsigned int*)0x40004018; //Match Register 0
unsigned int volatile *const T0MR1 = (unsigned int*)0x4000401C; //Match Register 1
unsigned int volatile *const PCLKSEL0 = (unsigned int*)0x400FC1A8; //PCLKSEL0 elije el periferico al que le asigna el clock

// Registro para declarar prioridades
unsigned int volatile *const IPR5 = (unsigned int*)0xE000E414; //Registro de prioridades


int contador =0; // contador que aumentara si el giro es en sentido horario (dextrogiro)
					 // y descendera si el giro es en sentido antihorario (levogiro)

int valor_anterior =0; // valor anterior medido por el adc

int main(void) {

	*IPR5|=(1>>22);
	*IPR5|=(1>>23); // configuramos una baja prioridad para el ADC


	*FIO0DIR|=(1<<7); //pin para controlar el terminal 1
	*FIO0DIR|=(1<<8); //pin para controlar el terminal 2
	*FIO0DIR|=(1<<6); // pin para habilitar el punte H

	LPC_GPIO0->FIODIR|=(1<<9); // P0.9 SE USARA PARA ENERGIZAR EL ENCODER
	LPC_GPIO3->FIODIR|=(1<<25); // P3.25 LED VERDE
	LPC_GPIO3->FIODIR|=(1<<26); // P3.26 LED AZUL
	*PINSEL4 |= (1<<20); // CONFIGURAMOS P2.10 PARA USAR EINT0
	LPC_GPIO2->FIODIR|= (0<<10); //PIN 2.10 ENTRADA
	LPC_GPIO2->FIODIR|= (0<<11); //PIN 2.11 ENTRADA
	LPC_SC->EXTINT|=(1<<0); // HABILITAMOS EINT0
	LPC_SC->EXTMODE|=(1<<0); //INTERRUPCION EXTERNA EINT0 POR FLANCO
	LPC_SC->EXTPOLAR|=(1<<0); // INTERRUPCION EXTERNA EINT0 POR FLANCO ASCENDENTE



	LPC_SC->PCONP |=(1<<1); //Enciendo el timer0
	LPC_SC->PCONP |= (1 << 25); //ENCENDEMOS EL PERIFERICO UART3

	*LCR |= (1 << 0); // PARA UNA LONGITUD DEL MENSAJE DE 8 BITS
	*LCR |= (1 << 1); // CONFIGURO LOS BITS 0 Y 1
	*LCR |= (1 << 7); //PARA ACCEDER A DLL Y DLM
    //CONFIGURACION DE TASA DE TRANSMISION A 9600
	    *DLL = 162;
	    *DLM = 0;
	    *LCR &= ~(1 << 7); //YA CONFIGURADO, DESHABILITO EL ACCESO
	    *IER |= (1 << 0); //HABILITO INTERR. DE RECEPCION
	    *ISER |= (1 << 8);
	    *PINSEL0 |= (1 << 1); //HABILITO TX3
	    *PINSEL0 |= (1 << 3); //HABILITO RX3

	    LPC_GPIO0->FIOSET|=(1<<9); //PONGO UN 1 EN P0.9 PARA ENERGIZAR EL ENCODER


	    	*PCLKSEL0|=(1<<2); // Habilito el clock para el timer0
	    	*PCLKSEL0|=(1<<3);

	    	//Configuracion del Timer0
	    	*T0PR = 0; //Al poner el Preescaler igual a 0, el timer counter se incrementara con cada pulso de clock
	    	*T0MR0 = 30000; // Cargo un valor al MR0
	    	*T0MR1 = 500000; // Cargo un valor al MR1

	    	//Configuracion del MCR
	    	*T0MCR|=(1<<0); // Se genera una interrupcion cuando el MR0 se matchea con el TC (timer counter)
	    	*T0MCR|=(1<<3); // Se genera una interrupcion cuando el MR1 se matchea con el TC (timer counter)
	    	*T0MCR|=(1<<4); // Se reinicia el TC cuando el MR1 se matchea con el.

	        // INICIO EL TIMER COUNTER DEL TIMER 0
	    	*T0TCR|=(1<<0);
	    	*FIO0SET=(1<<6); // habilitamos el motor A
	    	*ISER0|= (1<<18); //INTERRUPCION EINT0 EN P2.10
	    	*ISER0|=(1<<1); // Habilito las interrupciones por TIMER0

	    	//ADC
	    	LPC_SC->PCONP|=(1<<12); //Habilito energia para el ADC
	    	LPC_PINCON->PINSEL1|=(1<<14); // P0.23 como CH0 del ADC
	    	LPC_PINCON->PINMODE1|=(1<<15); // Las resistencias pull-up y pull-down del pin P0.23 estan desactivadas
	    	/*LPC_ADC->ADCR|=(1<<0); // Conversion por canal 0
	    	LPC_ADC->ADCR|=(1<<9); // Divisor del pclock por 2, para que quede 12,5 MHz
	    	LPC_ADC->ADCR|=(1<<16); // ADC en modo BURST
	    	*/
	    	LPC_ADC->ADCR=0x00210101;
	    	LPC_ADC->ADINTEN|=(1<<0); // Configuramos interrupciones para el canal 0

	    	NVIC_EnableIRQ(ADC_IRQn); // Habilitamos interrupcion global de NVIC

    return 0 ;
}


void EINT0_IRQHandler (void)
{
	//char buffer[20]; // para almacenar el valor convertido
	if (LPC_GPIO2->FIOPIN&(1<<11))
	{ 	LPC_GPIO3->FIOSET|=(1<<26);
		contador++; // si el giro es hacia la derecha aumenta el contador
		LPC_GPIO3->FIOCLR|=(1<<25);
	}
	else
	{LPC_GPIO3->FIOSET|=(1<<25);
		contador--; // si el giro es hacia la izquierda disminuye el contador
		LPC_GPIO3->FIOCLR|=(1<<26);
	}
	//itoa (contador, buffer,10);
	Enviar (contador);
	LPC_SC->EXTINT|=(1<<0); //BAJO BANDERA

}

void Enviar (char k){
	*THR=k;
}

void TIMER0_IRQHandler (void)
{
	if (*T0IR &(1<<0))
	{   *FIO0SET|=(1<<7);
		//*FIO0CLR1=(1<<7);
	if (!(*T0MR0 < 10000))
	*T0MR0= *T0MR0 - 2000;

      LPC_TIM0->IR=1;
			}
	else if (*T0IR &(1<<1))
	{   *FIO0CLR|=(1<<7); // Apago el LED VERDE del RGB
		//*FIO0CLR|=(1<<8); //Prendo el LED AZUL del RGB
	LPC_TIM0->IR|=(1<<1);

	}
}

void ADC_IRQHandler(void)
{
	int aux =((LPC_ADC->ADDR0& (0xfff<<4))>>4);
		if (aux <2048)
	{
		LPC_GPIO0->FIOSET|=(1<<7);
		LPC_GPIO0->FIOCLR|=(1<<8); // Giro hacia la izquierda
	}
	else
	{
		LPC_GPIO0->FIOSET|=(1<<8);
		LPC_GPIO0->FIOCLR|=(1<<7); // Giro hacia la derecha
	}

}

